import random
import time

from old_Commands import old_Commands
from old_HerbloreBot import HerbloreBot
from old_SmithingBot import SmithingBot
from old_User import User


class GameManager:
    class TypeOfBots:
        SMITHING = "Smithing"
        HERBLORE = "Herblore"

    class Coordinates:
        USERNAME = [3395, 413]
        PASSWORD = [3387, 507]
        LOGIN = [3509, 554]
        WORLD_1 = [3729, 529]
        WORLD_2 = [3727, 577]

    def __init__(self):
        self.list_of_user_info = [
            # ["adijrunescape@gmail.com", "deejian8", GameManager.TypeOfBots.HERBLORE]
            ["runescapejian9@googlemail.com", "deejian8", GameManager.TypeOfBots.SMITHING],
            ["runescapejian001@gmail.com", "deejian8", GameManager.TypeOfBots.SMITHING],
            ["runescapejian001@googlemail.com", "deejian8", GameManager.TypeOfBots.SMITHING],
            ["runescapejian002@gmail.com", "deejian8", GameManager.TypeOfBots.SMITHING],
            ["runescapejian002@googlemail.com", "deejian8", GameManager.TypeOfBots.SMITHING],
            ["runescapejian003@gmail.com", "deejian8", GameManager.TypeOfBots.SMITHING]
            ## ["runescapejian003@googlemail.com", "deejian8", BotRunner.TypeOfBots.SMITHING]
        ]
        self.list_of_user_objects = []
        for _user in self.list_of_user_info:
            new_user = User(_user[0], _user[1], _user[2])
            self.list_of_user_objects.append(new_user)

    @staticmethod
    def standard_start(user: User):
        user.start_game()
        user.login(game_manager.Coordinates.USERNAME, game_manager.Coordinates.PASSWORD, game_manager.Coordinates.LOGIN)
        user.choose_world(game_manager.Coordinates.WORLD_1, game_manager.Coordinates.WORLD_2)

    @staticmethod
    def custom_start(rep_count, type_of_product):
        old_Commands.GameRunner.stop_runescape()
        for i in game_manager.list_of_user_objects:
            game_manager.standard_start(i)
            if i.type == GameManager.TypeOfBots.SMITHING:
                SmithingBot.reset_interface(i.window_hwnd, type_of_product)
            if i.type == GameManager.TypeOfBots.HERBLORE:
                HerbloreBot.reset_interface(i.window_hwnd)

        for t in range(rep_count):
            for p in game_manager.list_of_user_objects:
                if p.type == GameManager.TypeOfBots.SMITHING:
                    SmithingBot.run(p.window_hwnd, SmithingBot.OptionalCoordinates.START_PROJECT)
                    p.window_to_back()
                if p.type == GameManager.TypeOfBots.HERBLORE:
                    HerbloreBot.run(p.window_hwnd)
            old_Commands.Prints.print_info(f'Repeat: {t}/{rep_count}')

            time.sleep(random.randint(60, 65))


if __name__ == "__main__":
    game_manager = GameManager()
    # Commands.ClickCommander.find_coordinates()

    # game_manager.custom_start(250, SmithingBot.OptionalCoordinates.ARROWS)
    # Commands.GameRunner.stop_runescape()
    # print("Be back in 60")
    # time.sleep(60 * 60)
    # game_manager.custom_start(200, SmithingBot.OptionalCoordinates.BOLTS)
    old_Commands.GameRunner.stop_runescape()
