import subprocess
import time
import webbrowser
from datetime import datetime

import keyboard
import pyautogui
import win32con
import win32gui


class old_Commands:

    class Prints:
        class Colors:
            HEADER = '\033[95m'
            OKBLUE = '\033[94m'
            OKCYAN = '\033[96m'
            OKGREEN = '\033[92m'
            WARNING = '\033[93m'
            FAIL = '\033[91m'
            ENDC = '\033[0m'
            BOLD = '\033[1m'
            UNDERLINE = '\033[4m'

        @staticmethod
        def print_error(text):
            print(f"{old_Commands.Prints.Colors.FAIL}", datetime.now().strftime('%H:%M:%S'), text, f"{old_Commands.Prints.Colors.ENDC}")

        @staticmethod
        def print_info(text):
            print(f"{old_Commands.Prints.Colors.OKCYAN}", datetime.now().strftime('%H:%M:%S'), text, f"{old_Commands.Prints.Colors.ENDC}")

    class ClickCommander:
        @staticmethod
        def click_coordinates(coordinates: list):
            try:
                pyautogui.click(coordinates[0], coordinates[1])
            except Exception as e:
                old_Commands.Prints.print_error(f"Failed to left click {coordinates} due to {e}")

        @staticmethod
        def right_click_coordinates(coordinates: list):
            try:
                pyautogui.click(coordinates[0], coordinates[1])
            except Exception as e:
                old_Commands.Prints.print_error(f"Failed to right click {coordinates} due of {e}")

        @staticmethod
        def find_coordinates():
            while True:
                if keyboard.is_pressed('p'):
                    print(pyautogui.position())
                    time.sleep(0.1)
                elif keyboard.is_pressed('q'):
                    break

    class ImageDetectionManager:
        @staticmethod
        def locateImageOnScreen(self, image):
            counter = 0
            for _ in pyautogui.locateAllOnScreen(self, image(image), confidence=0.94, grayscale=True):
                counter += 1
                print(_)
            return counter

    class GameRunner:
        @staticmethod
        def run_runescape(user):
            path = 'rs-launch://www.runescape.com/k=5/l=$(Language:0)/jav_config.ws'
            webbrowser.open(path)
            time.sleep(10)

        @staticmethod
        def stop_runescape():
            subprocess.call("TASKKILL /F /IM Runescape.exe", shell=True)
            old_Commands.Prints.print_info(f"Ended all Runescape tasks")

    class WindowManager:

        @staticmethod
        def get_list_of_windows():
            list_of_windows = []
            try:
                def winEnumHandler(hwnd, ctx):
                    if win32gui.IsWindowVisible(hwnd):
                        if win32gui.GetWindowText(hwnd) == 'RuneScape':
                            # print(hwnd, win32gui.GetWindowText(hwnd), ",")
                            list_of_windows.append(hwnd)

                win32gui.EnumWindows(winEnumHandler, None)
            except Exception as e:
                old_Commands.Prints.print_error(f"Failed to get list of windows: {e}")

            old_Commands.Prints.print_info(f"List_of_windows: {list_of_windows}")
            return list_of_windows

        @staticmethod
        def generate_list_moves(click_commander):
            click_commander.find_coordinates()

        @staticmethod
        def window_set_pos(hwnd):
            try:
                rect = win32gui.GetWindowRect(hwnd)
                win32gui.MoveWindow(hwnd, 2552, -8, 1920, 1080, True)
                print(win32gui.GetWindowText(hwnd), "hwnd", hwnd, "rect", rect)
            except Exception as e:
                rect = win32gui.GetWindowRect(hwnd)
                win32gui.MoveWindow(hwnd, 2552, -8, 1920, 1080, True)
                print(win32gui.GetWindowText(hwnd), "hwnd", hwnd, "rect", rect)
                old_Commands.Prints.print_error(f"Failed to set position of window {hwnd} due to {e}")

        @staticmethod
        def window_bring_to_front(hwnd):
            try:
                win32gui.ShowWindow(hwnd, win32con.SW_MINIMIZE)
                win32gui.ShowWindow(hwnd, win32con.SW_MAXIMIZE)
                win32gui.SetActiveWindow(hwnd)
                win32gui.SetForegroundWindow(hwnd)
            except Exception as e:
                win32gui.ShowWindow(hwnd, win32con.SW_MINIMIZE)
                win32gui.ShowWindow(hwnd, win32con.SW_MAXIMIZE)
                win32gui.SetActiveWindow(hwnd)
                win32gui.SetForegroundWindow(hwnd)
                old_Commands.Prints.print_error(f"Failed to bring window {hwnd} to front due to {e}")

        @staticmethod
        def window_bring_to_back(hwnd):
            try:
                win32gui.ShowWindow(hwnd, win32con.SW_MINIMIZE)
            except Exception as e:
                win32gui.ShowWindow(hwnd, win32con.SW_MINIMIZE)
                old_Commands.Prints.print_error(f"Failed to minimize window {hwnd} due to {e}")
