import random
import time

import keyboard
import pyautogui
import win32api
import win32con

from old_Commands import old_Commands


class HerbloreBot:
    class Coordinates:
        BANK_1 = [3539, 795]
        WELL_2 = [3499, 482]

    @staticmethod
    def run(window):
        old_Commands.WindowManager.window_bring_to_front(window)
        time.sleep(random.randint(1, 2))
        old_Commands.ClickCommander.click_coordinates([HerbloreBot.Coordinates.BANK_1[0] + random.randint(0, 10), HerbloreBot.Coordinates.BANK_1[1] + random.randint(0, 10)])
        time.sleep(random.randint(1, 2))
        pyautogui.press("1")
        time.sleep(random.randint(1, 2))
        old_Commands.ClickCommander.click_coordinates([HerbloreBot.Coordinates.WELL_2[0] + random.randint(0, 10), HerbloreBot.Coordinates.WELL_2[1] + random.randint(0, 10)])
        time.sleep(random.randint(1, 2))
        pyautogui.press("space")
        time.sleep(random.randint(16, 18))

    @staticmethod
    def reset_interface(window):
        old_Commands.WindowManager.window_bring_to_front(window)
        keyboard.press('up')
        time.sleep(random.randint(2, 3))
        keyboard.release('up')
        time.sleep(random.randint(1, 2))
        old_Commands.Prints.print_info(f"Reset window {window} to position")


