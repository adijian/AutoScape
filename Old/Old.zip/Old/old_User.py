import time

import keyboard

from old_Commands import old_Commands


class User:
    def __init__(self, username, password, bot_type):
        self.username = username
        self.password = password
        self.type = bot_type
        self.window_hwnd = ''

    def get_window(self):
        self.window_hwnd = old_Commands.WindowManager.get_list_of_windows()[0]
        old_Commands.Prints.print_info(f"The window '{self.window_hwnd}' was created for '{self.username}'")

    def start_game(self):
        old_Commands.GameRunner.run_runescape(self.username)
        self.get_window()
        self.window_to_back()

    def window_to_front(self):
        old_Commands.WindowManager.window_bring_to_front(self.window_hwnd)

    def window_to_back(self):
        old_Commands.WindowManager.window_bring_to_back(self.window_hwnd)

    def login(self, coordinates_username, coordinates_password, coordinates_login):
        self.window_to_front()
        old_Commands.WindowManager.window_set_pos(self.window_hwnd)
        self.window_to_front()
        time.sleep(1)
        old_Commands.ClickCommander.click_coordinates(coordinates_username)
        keyboard.write(self.username)
        time.sleep(1)
        old_Commands.ClickCommander.click_coordinates(coordinates_password)
        keyboard.write(self.password)
        time.sleep(1)
        old_Commands.ClickCommander.click_coordinates(coordinates_login)
        time.sleep(8)
        self.window_to_back()
        time.sleep(1)
        old_Commands.Prints.print_info(f"The user {self.username} has logged in")

    def choose_world(self, coordinates_world1, coordinates_world2):
        self.window_to_front()
        old_Commands.ClickCommander.click_coordinates(coordinates_world1)
        old_Commands.ClickCommander.click_coordinates(coordinates_world2)
        time.sleep(1)
        old_Commands.ClickCommander.click_coordinates(coordinates_world1)
        old_Commands.ClickCommander.click_coordinates(coordinates_world2)
        time.sleep(8)
        self.window_to_back()
        time.sleep(1)
        old_Commands.Prints.print_info(f"The user {self.username} has chose world")
