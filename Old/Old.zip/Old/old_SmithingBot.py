import random
import time

import keyboard
import win32api
import win32con

from old_Commands import old_Commands


class SmithingBot:
    class Coordinates:
        ANVIL_1 = [3679, 741]
        RUNE_BAR_2 = [3210, 423]
        BLANK_SPOT_INTERFACE_3 = [3557, 473]

    class OptionalCoordinates:
        ARROWS = [3409, 608]
        BOLTS = [3509, 602]
        START_PROJECT = [3677, 745]

    @staticmethod
    def run(window, project_coordinates):
        old_Commands.WindowManager.window_bring_to_front(window)
        for i in range(2):
            coordinates_begin_project = [project_coordinates[0] + random.randint(0, 10), project_coordinates[1] + random.randint(0, 10)]
            old_Commands.ClickCommander.click_coordinates(coordinates_begin_project)
            time.sleep(1)
        old_Commands.WindowManager.window_bring_to_back(window)

    @staticmethod
    def reset_interface(window, project_coordinates):
        old_Commands.WindowManager.window_bring_to_front(window)
        keyboard.press('up')
        time.sleep(2)
        keyboard.release('up')
        for i in range(10):
            keyboard.press_and_release('right')
            time.sleep(0.2)
        win32api.mouse_event(win32con.MOUSEEVENTF_WHEEL, 3557, 473, 100000, 0)

        time.sleep(5)
        old_Commands.ClickCommander.click_coordinates(SmithingBot.Coordinates.ANVIL_1)
        time.sleep(2)
        old_Commands.ClickCommander.click_coordinates(SmithingBot.Coordinates.RUNE_BAR_2)
        time.sleep(2)
        old_Commands.ClickCommander.click_coordinates(SmithingBot.Coordinates.BLANK_SPOT_INTERFACE_3)
        time.sleep(2)
        win32api.mouse_event(win32con.MOUSEEVENTF_WHEEL, 3557, 473, -1000, 0)
        time.sleep(2)
        old_Commands.ClickCommander.click_coordinates(project_coordinates)
        time.sleep(2)
        old_Commands.WindowManager.window_bring_to_back(window)

        old_Commands.Prints.print_info(f"Reset window {window} to position")

